ADMIN
username: admin
password: admin

PETUGAS
username: petugas
password: petugas