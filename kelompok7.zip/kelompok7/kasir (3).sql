-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Apr 2024 pada 16.38
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kasir`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `detailpenjualan`
--

CREATE TABLE `detailpenjualan` (
  `detail_id` int(11) NOT NULL,
  `penjualan_id` int(11) DEFAULT NULL,
  `produk_id` int(11) DEFAULT NULL,
  `kode_produk` varchar(15) NOT NULL,
  `jumlah_produk` int(11) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `detailpenjualan`
--

INSERT INTO `detailpenjualan` (`detail_id`, `penjualan_id`, `produk_id`, `kode_produk`, `jumlah_produk`, `subtotal`) VALUES
(34, 26, NULL, 'C.002', 4, NULL),
(35, 27, NULL, 'C.002', 3, NULL),
(38, 28, NULL, 'C.005', 5, NULL),
(39, 29, NULL, 'X.001', 1, NULL),
(40, 29, NULL, 'M.006', 1, NULL),
(41, 29, NULL, 'C.004', 4, NULL),
(42, 34, NULL, 'X.001', 5, 0.00),
(45, 35, NULL, 'C.003', 5, 115000.00),
(46, 35, NULL, 'X.001', 1, 15000.00),
(47, 35, NULL, 'C.008', 1, 24000.00),
(48, 36, NULL, 'C.002', 1, 22000.00),
(49, 37, NULL, 'X.001', 4, 20000.00),
(50, 38, NULL, 'M.005', 3, 24000.00),
(51, 38, NULL, 'M.006', 3, 36000.00),
(52, 39, NULL, 'M.006', 1, 12000.00),
(53, 41, NULL, 'C.008', 1, 24000.00),
(54, 41, NULL, 'C.006', 2, 48000.00),
(55, 42, NULL, 'X.001', 5, 25000.00),
(57, 50, NULL, 'H.002', 1, 500000.00),
(58, 30, NULL, 'X.001', 2, NULL),
(59, 30, NULL, 'X.001', 3, NULL),
(61, 51, NULL, 'X.001', 1, 5000.00),
(62, 51, NULL, 'G.003', 1, 17000.00),
(63, 52, NULL, '0', 1, 0.00),
(64, 52, NULL, '0', 1, 0.00),
(65, 52, NULL, 'X.001', 1, 5000.00),
(67, 53, NULL, 'C.001', 4, 88000.00),
(68, 54, NULL, 'C.003', 1, 23000.00),
(69, 55, NULL, 'K.001', 1, 13000.00);

--
-- Trigger `detailpenjualan`
--
DELIMITER $$
CREATE TRIGGER `kurangi_stok_produk` AFTER INSERT ON `detailpenjualan` FOR EACH ROW BEGIN
    DECLARE stok_produk INT;

    -- Ambil jumlah stok produk sebelumnya
    SELECT stok INTO stok_produk FROM produk WHERE kode_produk = NEW.kode_produk;

    -- Kurangi jumlah stok produk dengan jumlah terjual
    UPDATE produk SET stok = stok_produk - NEW.jumlah_produk WHERE kode_produk = NEW.kode_produk;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_stok_after_sale` AFTER INSERT ON `detailpenjualan` FOR EACH ROW BEGIN
    DECLARE sold_quantity INT;
    
    -- Ambil jumlah produk yang terjual dari detailpenjualan
    SELECT jumlah_produk INTO sold_quantity FROM detailpenjualan WHERE detail_id = NEW.detail_id;
    
    -- Kurangi stok produk yang terjual
    UPDATE produk SET stok = stok - sold_quantity WHERE produk_id = NEW.produk_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `kode_kategori` varchar(15) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`) VALUES
(1, 'A.001', 'Makanan'),
(2, 'B.001', 'Minuman'),
(6, 'C.001', 'Kecantikan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `pelanggan_id` int(11) NOT NULL,
  `nama_pelanggan` varchar(255) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `nomor_telepon` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`pelanggan_id`, `nama_pelanggan`, `alamat`, `nomor_telepon`) VALUES
(1, 'aidah', 'dawuan', '082316366069'),
(2, 'jabir', 'sinarjati', '087541352012'),
(3, 'zarra', 'baturuyuk', '083837209566'),
(4, 'melani', 'burujul wetan', '082316377852'),
(5, 'asep', 'girimukti', '082645299632'),
(6, 'rafly', 'mandapa', '082751456125'),
(7, 'bunga', 'cikiok', '0815452687236'),
(8, 'nova', 'lewihujan', '0825146344528'),
(9, 'yuli', 'sumedang', '082156245487'),
(10, 'putra', 'babakan', '082157566157'),
(11, 'umum', 'majalengka', '08123456789');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE `penjualan` (
  `penjualan_id` int(11) NOT NULL,
  `tgl_penjualan` date DEFAULT NULL,
  `nama_user` varchar(255) NOT NULL,
  `bayar` decimal(10,2) NOT NULL,
  `total_harga` decimal(10,2) DEFAULT NULL,
  `pelanggan_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `penjualan`
--

INSERT INTO `penjualan` (`penjualan_id`, `tgl_penjualan`, `nama_user`, `bayar`, `total_harga`, `pelanggan_id`) VALUES
(36, '2024-04-17', 'Admin', 0.00, 22000.00, 2),
(37, '2024-04-17', 'Admin', 25000.00, 20000.00, 2),
(38, '2024-04-17', 'Admin', 100000.00, 96000.00, 3),
(39, '2024-04-17', 'Admin', 25000.00, 24000.00, 3),
(40, '2024-04-17', 'Admin', 0.00, NULL, 3),
(41, '2024-04-17', 'Admin', 72000.00, 72000.00, 3),
(42, '2024-04-17', 'Admin', 25000.00, 25000.00, 2),
(43, '2024-04-18', 'Petugas', 0.00, NULL, 1),
(44, '2024-04-18', 'Petugas', 0.00, NULL, 0),
(45, '2024-04-18', 'Petugas', 0.00, NULL, 0),
(46, '2024-04-18', 'Petugas', 0.00, NULL, 0),
(47, '2024-04-18', 'Petugas', 0.00, NULL, 0),
(48, '2024-04-18', 'Petugas', 22000.00, 22000.00, 6),
(49, '2024-04-18', 'Petugas', 0.00, NULL, 3),
(50, '2024-04-18', 'Petugas', 710000.00, 610000.00, 5),
(51, '2024-04-18', 'Admin', 25000.00, 22000.00, 3),
(52, '2024-04-20', 'Admin', 0.00, NULL, 3),
(53, '2024-04-21', 'Admin', 100000.00, 88000.00, 6),
(54, '2024-04-21', 'Admin', 23000.00, 23000.00, 6),
(55, '2024-04-21', 'Admin', 15000.00, 13000.00, 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `produk_id` int(11) NOT NULL,
  `kode_produk` varchar(15) NOT NULL,
  `nama_produk` varchar(255) DEFAULT NULL,
  `kode_kategori` varchar(15) NOT NULL,
  `harga` decimal(10,2) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`produk_id`, `kode_produk`, `nama_produk`, `kode_kategori`, `harga`, `stok`) VALUES
(1, 'X.001', 'Kue Putu', 'A.001', 5000.00, 18),
(2, 'K.001', 'Minyak Goreng', 'A.001', 13000.00, 88),
(3, 'H.002', 'Handphone', 'A.002', 500000.00, 100),
(4, 'C.001', 'Akar kelapa', 'A.001', 22000.00, 10),
(5, 'C.002', 'Kue Bawang', '', 22000.00, 20),
(6, 'C.003', 'Pastel Kering', 'A.001', 23000.00, 19),
(7, 'C.004', 'Kue Keciput', 'A.001', 21000.00, 20),
(8, 'C.005', 'Kue Biji Ketapang', 'A.001', 23000.00, 20),
(9, 'C.006', 'Butter Cookies', 'A.001', 24000.00, 20),
(10, 'C.007', 'Lidah Kucing', 'A.001', 23000.00, 20),
(11, 'C.009', 'Nastar Kurma', 'A.001', 24000.00, 20),
(12, 'C.008', 'Kue Putri Salju', 'A.001', 24000.00, 20),
(13, 'C.010', 'Kue Sagu', 'A.001', 21000.00, 20),
(14, 'M.001', 'Ultramilk Full Cream 200ml', 'B.001', 7000.00, 25),
(15, 'M.002', 'Ultramilk Coklat 200ml', 'B.001', 7000.00, 25),
(16, 'M.003', 'Ultramilk Stroberi 200ml', 'B.001', 8000.00, 25),
(17, 'M.004', 'Oatside Coffe 200ml', 'B.001', 8000.00, 15),
(18, 'M.005', 'Oatside Chocolate 200ml', 'B.001', 8000.00, 15),
(19, 'M.006', 'Ichitan Thai Tea 300ml', 'B.001', 12000.00, 15),
(20, 'M.006', 'Ichitan Brown Sugar 300ml', 'B.001', 12000.00, 15),
(21, 'M.007', 'Cimory Squeeze Brown Sugar 120ml', 'B.001', 10000.00, 10),
(22, 'M.009', 'Cimory Squeeze Original 120ml', 'B.001', 10000.00, 10),
(23, 'G.001', 'Snickers 70G', 'A.001', 357200.00, 10),
(24, 'G.002', 'Dairy Milk 62G', 'A.001', 13000.00, 10),
(25, 'G.003', 'Silverquen Almond Coklat 58G', 'A.001', 17000.00, 9),
(26, 'G.004', 'Kinder Joy ', 'A.001', 10000.00, 10),
(27, 'G.005', 'ChicChoc Biscuit 40G', '', 10000.00, 10),
(28, 'S.001', 'Potabee Barbeque Beef 68G', '', 9000.00, 20),
(29, 'S.002', 'Potabee Barbeque Beef 120G', '', 16000.00, 20),
(30, 'S.003', 'Taro Net Snack Seaweed 115G', '', 16000.00, 20),
(31, 'C.007', 'lipstik', 'kecantikan', 30000.00, 10),
(32, 'F.001', 'Permen Fox', '', 500.00, 100);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `nama_user` varchar(255) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `level` enum('admin','petugas','kasir') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`user_id`, `nama_user`, `username`, `password`, `level`) VALUES
(8, 'siapa', 'siapa', '2128e15b849bb3d5b1fa88cc18d494fe', 'admin'),
(10, 'Admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(11, 'Petugas', 'petugas', 'afb91ef692fd08c445e8cb1bab2ccf9c', 'petugas'),
(12, 'Jabir', 'jabir', 'e10adc3949ba59abbe56e057f20f883e', 'petugas'),
(13, 'Aidah', 'aidah', '2554e69046e755c376a19eabe3465fff', 'petugas'),
(14, 'Zara', 'zara', 'b35f8922ff1d54a5aff55a1d4107e245', 'petugas'),
(15, 'Melani', 'melani', 'bf6c13136ba681f8daa4fbd472cd404c', 'petugas'),
(16, 'Rafli', 'rafli', '054a3c3033e8f672358b1e159aecc7a7', 'petugas');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `detailpenjualan`
--
ALTER TABLE `detailpenjualan`
  ADD PRIMARY KEY (`detail_id`),
  ADD KEY `PenjualanID` (`penjualan_id`),
  ADD KEY `ProdukID` (`produk_id`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`pelanggan_id`);

--
-- Indeks untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`penjualan_id`),
  ADD KEY `PelangganID` (`pelanggan_id`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`produk_id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `detailpenjualan`
--
ALTER TABLE `detailpenjualan`
  MODIFY `detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `pelanggan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `penjualan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `produk_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
